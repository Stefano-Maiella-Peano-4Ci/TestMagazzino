/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testmagazzino;

/**
 *
 * @author maiella.stefano
 */
public abstract class Pesce {
    public String getLuogoPesca(){
        return null;
    }
    public String getTempCons(){
        String tempCons = null;
        return tempCons;
    }
}
