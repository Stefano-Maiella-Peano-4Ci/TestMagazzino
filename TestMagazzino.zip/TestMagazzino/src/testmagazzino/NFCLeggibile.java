/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testmagazzino;

/**
 *
 * @author maiella.stefano
 */
public interface NFCLeggibile {
    public String getPosizione();
    public String getId();
}
