/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testmagazzino;

import java.util.ArrayList;

/**
 *
 * @author maiella.stefano
 */
public class Magazzino {
    ArrayList<Settore>settori;

    public Magazzino(ArrayList<Settore> settori) {
        settori = new ArrayList();
    }

    public Magazzino() {
    }
    
    

    
    
    
}
